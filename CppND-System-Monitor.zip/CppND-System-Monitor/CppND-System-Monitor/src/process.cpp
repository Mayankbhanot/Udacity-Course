#include <unistd.h>
#include <cctype>
#include <sstream>
#include <string>
#include <vector>
#include <iostream>

#include "process.h"
#include "linux_parser.h"

using std::string;
using std::to_string;
using std::vector;

// Return the process ID of this process
int Process::Pid() const {
    return pid_;
}

void Process::SetPid(int pid) {
    pid_ = pid;
}

// Return the CPU utilization of this process
float Process::CpuUtilization() {
    vector<string> statValues = LinuxParser::CpuUtilization(Pid());
    long uptime, utime, stime, cutime, cstime, starttime, totalTime, seconds;
    float cpuUsage;
    uptime = LinuxParser::UpTime();

    utime = std::stol(statValues[13]);
    stime = std::stol(statValues[14]);
    cutime = std::stol(statValues[15]);
    cstime = std::stol(statValues[16]);
    starttime = std::stol(statValues[21]);
    totalTime = utime + stime + cutime + cstime;
    
    seconds = uptime - (starttime / sysconf(_SC_CLK_TCK));
    cpuUsage = 100.0 * totalTime / sysconf(_SC_CLK_TCK) / seconds;
    return cpuUsage;
}

// Return the command that generated this process
string Process::Command() {
    return LinuxParser::Command(Pid());
}

// Return the memory usage of this process
string Process::Ram() const {
    return LinuxParser::Ram(Pid());
}

// Return the user that started this process
string Process::User() {
    return LinuxParser::User(Pid());
}

// Return the age of this process in seconds
long int Process::UpTime() {
    return LinuxParser::UpTime() - LinuxParser::UpTime(Pid());
}

// Overload the less-than operator for sorting Processes by memory usage
bool Process::operator<(Process const& a) const {
    return std::stol(Ram()) > std::stol(a.Ram());
}
