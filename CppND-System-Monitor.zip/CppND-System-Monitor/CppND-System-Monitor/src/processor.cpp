#include <iostream>
#include "processor.h"
#include "linux_parser.h"

// Return the overall CPU utilization
float Processor::Utilization() { 
    long totalJiffies = LinuxParser::Jiffies();
    long idleJiffies = LinuxParser::IdleJiffies();
    return 1.0 * (totalJiffies - idleJiffies) / totalJiffies; 
}
