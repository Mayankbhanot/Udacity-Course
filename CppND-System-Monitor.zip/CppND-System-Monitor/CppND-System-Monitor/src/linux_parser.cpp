#include <dirent.h>
#include <sstream>
#include <string>
#include <vector>
#include <iostream>
#include <fstream>
#include <algorithm>
#include <unistd.h>

#include "linux_parser.h"

using std::ifstream;
using std::istringstream;
using std::replace;
using std::string;
using std::to_string;
using std::vector;

string LinuxParser::OperatingSystem() {
  string line, key, value;
  ifstream filestream(kOSPath);
  if (filestream.is_open()) {
    while (std::getline(filestream, line)) {
      replace(line.begin(), line.end(), ' ', '_');
      replace(line.begin(), line.end(), '=', ' ');
      replace(line.begin(), line.end(), '"', ' ');
      istringstream linestream(line);
      while (linestream >> key >> value) {
        if (key == "PRETTY_NAME") {
          replace(value.begin(), value.end(), '_', ' ');
          return value;
        }
      }
    }
  }
  return value;
}

string LinuxParser::Kernel() {
  string os, kernel, version;
  string line;
  ifstream stream(kProcDirectory + kVersionFilename);
  if (stream.is_open()) {
    std::getline(stream, line);
    istringstream linestream(line);
    linestream >> os >> version >> kernel;
  }
  return kernel;
}

vector<int> LinuxParser::Pids() {
  vector<int> pids;
  DIR* directory = opendir(kProcDirectory.c_str());
  struct dirent* file;
  while ((file = readdir(directory)) != nullptr) {
    if (file->d_type == DT_DIR) {
      string filename(file->d_name);
      if (std::all_of(filename.begin(), filename.end(), isdigit)) {
        int pid = stoi(filename);
        pids.push_back(pid);
      }
    }
  }
  closedir(directory);
  return pids;
}

float LinuxParser::MemoryUtilization() {
  string line, key;
  float value, mem_total, mem_free;
  ifstream filestream(kProcDirectory + kMeminfoFilename);
  if (filestream.is_open()) {
    while (getline(filestream, line)) {
      istringstream linestream(line);
      linestream >> key >> value;
      if (key == "MemTotal:") {
        mem_total = value;
      } else if (key == "MemFree:") {
        mem_free = value;
      }
    }
  }
  return (mem_total - mem_free) / mem_total;
}

long LinuxParser::UpTime() {
  string line;
  long uptime;
  double idle_time;
  ifstream filestream(kProcDirectory + kUptimeFilename);
  if (filestream.is_open()) {
    getline(filestream, line);
    istringstream linestream(line);
    linestream >> uptime >> idle_time;
  }
  return uptime;
}

long LinuxParser::Jiffies() {
  string line, key;
  long user, nice, system, idle, iowait, irq, softirq, steal, guest, guest_nice;
  ifstream filestream(kProcDirectory + kStatFilename);
  if (filestream.is_open()) {
    getline(filestream, line);
    istringstream linestream(line);
    linestream >> key >> user >> nice >> system >> idle >> iowait >> irq >> softirq >> steal >> guest >> guest_nice;
  }
  return idle + iowait + user + nice + system + irq + softirq + steal + guest + guest_nice;
}
// Read and return the number of active jiffies for the system
long LinuxParser::ActiveJiffies() {
string line, key;
long user, nice, system, idle, iowait, irq, softirq, steal, guest, guest_nice;
std::ifstream filestream(kProcDirectory + kStatFilename);
if (filestream.is_open()) {
while (std::getline(filestream, line)) {
std::istringstream linestream(line);
while (linestream >> key) {
if (key == "cpu") {
linestream >> user >> nice >> system >> idle >> iowait >> irq >> softirq >> steal >> guest >> guest_nice;
}
}
}
}
return user + nice + system + irq + softirq + steal;
}

// Read and return the number of idle jiffies for the system
long LinuxParser::IdleJiffies() {
string line, key;
long user, nice, system, idle, iowait, irq, softirq, steal, guest, guest_nice;
std::ifstream filestream(kProcDirectory + kStatFilename);
if (filestream.is_open()) {
while (std::getline(filestream, line)) {
std::istringstream linestream(line);
while (linestream >> key) {
if (key == "cpu") {
linestream >> user >> nice >> system >> idle >> iowait >> irq >> softirq >> steal >> guest >> guest_nice;
}
}
}
}
return idle + iowait;
}

// Read and return CPU utilization
vector<string> LinuxParser::CpuUtilization(int pid) {
string line;
std::vector<string> tokens;
std::ifstream filestream(kProcDirectory + std::to_string(pid) + kStatFilename);
if (filestream.is_open()) {
if (std::getline(filestream, line)) {
std::istringstream linestream(line);
while (linestream >> line) {
tokens.push_back(line);
}
}
}
return tokens;
}

// Read and return the total number of processes
int LinuxParser::TotalProcesses() {
string line;
string key;
int value = 0;
std::ifstream filestream(kProcDirectory + kStatFilename);
if (filestream.is_open()) {
while (std::getline(filestream, line)) {
std::istringstream linestream(line);
while (linestream >> key >> value) {
if (key == "processes") {
return value;
}
}
}
}
return value;
}

// Read and return the number of running processes
int LinuxParser::RunningProcesses() {
string line;
string key;
int value = 0;
std::ifstream filestream(kProcDirectory + kStatFilename);
if (filestream.is_open()) {
while (std::getline(filestream, line)) {
std::istringstream linestream(line);
while (linestream >> key >> value) {
if (key == "procs_running") {
return value;
}
}
}
}
return value;
}

// This function reads and returns the command associated with a given process ID
string LinuxParser::Command(int pid) {
string line;
string command;
// Open the file that contains the command information for the given process ID
std::ifstream filestream(kProcDirectory + std::to_string(pid) + kCmdlineFilename);
if (filestream.is_open()) {
// Read the first line from the file and return it as the command
if (std::getline(filestream, line)) {
command = line;
}
}
return command;
}

// This function reads and returns the memory used by a given process ID
string LinuxParser::Ram(int pid) {
string line;
string key;
long value;
// Open the file that contains the memory information for the given process ID
std::ifstream filestream(kProcDirectory + std::to_string(pid) + kStatusFilename);
if (filestream.is_open()) {
// Search for the line that contains the memory information
while (std::getline(filestream, line)) {
std::istringstream linestream(line);
if (linestream >> key >> value) {
if (key == "VmSize:") {
// Convert the memory value to megabytes and return it as a string
value /= 1000;
return std::to_string(value);
}
}
}
}
return "0";
}

// This function reads and returns the user ID associated with a given process ID
string LinuxParser::Uid(int pid) {
string line;
string key;
string value;
// Open the file that contains the user information for the given process ID
std::ifstream filestream(kProcDirectory + std::to_string(pid) + kStatusFilename);
if (filestream.is_open()) {
// Search for the line that contains the user ID information
while (std::getline(filestream, line)) {
std::istringstream linestream(line);
if (linestream >> key >> value) {
if (key == "Uid:") {
return value;
}
}
}
}
return value;
}


// This function reads and returns the user associated with a process
string LinuxParser::User(int pid) {
string uid = Uid(pid);
string line;
string user;
std::ifstream filestream(kPasswordPath);
if (filestream.is_open()) {
while (std::getline(filestream, line)) {
std::vector<std::string> tokens;
std::istringstream linestream(line);
  string token;
while (std::getline(linestream, token, ':')) {
tokens.push_back(token);
}
if (tokens[2] == uid){
user = tokens[0];
break;
}
}
}
return user;
}

// This function reads and returns the uptime of a process
long LinuxParser::UpTime(int pid) {
string line;
std::vector<string> tokens;
string token;
long uptime_seconds = 0;
std::ifstream filestream(kProcDirectory + std::to_string(pid) + kStatFilename);
if (filestream.is_open()) {
while (std::getline(filestream, line)) {
std::istringstream linestream(line);
while (std::getline(linestream, token, ' ')){
tokens.push_back(token);
}
}
}
uptime_seconds = std::stol(tokens[21]) / sysconf(_SC_CLK_TCK);
return uptime_seconds;
}