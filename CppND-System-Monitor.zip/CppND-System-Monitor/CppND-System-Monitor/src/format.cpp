#include <string>
#include <sstream>
#include <iomanip>

#include "format.h"

using std::string;

#define SECONDS_IN_AN_HOUR 3600
#define SECONDS_IN_A_MINUTE 60

// Converts seconds to string in the format of HH:MM:SS
string Format::ElapsedTime(long seconds) {
    int hours = seconds / SECONDS_IN_AN_HOUR;
    seconds %= SECONDS_IN_AN_HOUR;
    int minutes = seconds / SECONDS_IN_A_MINUTE;
    seconds %= SECONDS_IN_A_MINUTE;
    std::stringstream stream;
    stream << std::setw(2) << std::setfill('0') << hours << ":" 
           << std::setw(2) << std::setfill('0') << minutes << ":" 
           << std::setw(2) << std::setfill('0') << seconds;
    return stream.str();
}
